import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';

void main() {
  runApp(const AlsalmaniApp());
}

class AlsalmaniApp extends StatelessWidget {
  const AlsalmaniApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'السلماني',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const LoginPage(),
    );
  }
}

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});
  @override
  Widget build(BuildContext context) {
    final emailController = TextEditingController();
    final passwordController = TextEditingController();
    return Scaffold(
      appBar: AppBar(title: const Text('تسجيل الدخول')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            TextField(controller: emailController, decoration: const InputDecoration(labelText: 'البريد الإلكتروني')),
            const SizedBox(height: 12),
            TextField(controller: passwordController, obscureText: true, decoration: const InputDecoration(labelText: 'كلمة المرور')),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const DashboardPage()));
              },
              child: const Text('دخول'),
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('لوحة التحكم - السلماني')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(child: ListTile(title: const Text('عدد الشحنات الحالية'), trailing: const Text('3'))),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (_) => const NewShipmentPage()));
              },
              child: const Text('إضافة شحنة جديدة'),
            ),
          ],
        ),
      ),
    );
  }
}

class NewShipmentPage extends StatefulWidget {
  const NewShipmentPage({super.key});
  @override
  State<NewShipmentPage> createState() => _NewShipmentPageState();
}

class _NewShipmentPageState extends State<NewShipmentPage> {
  final List<String> shipmentTypes = ['بضائع عامة', 'مواد غذائية', 'مواد بناء'];
  final List<String> transportTypes = ['شاحنة', 'سيارة', 'دراجة'];
  String? selectedShipmentType;
  String? selectedTransportType;
  DateTime? shipmentDate;
  DateTime? arrivalDate;
  final TextEditingController priceController = TextEditingController();
  final List<String> deliveryLocations = [];
  final TextEditingController locationController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إضافة شحنة جديدة')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: 'نوع الشحنة'),
                items: shipmentTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (val) => setState(() => selectedShipmentType = val),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                decoration: const InputDecoration(labelText: 'وسيلة النقل'),
                items: transportTypes.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                onChanged: (val) => setState(() => selectedTransportType = val),
              ),
              const SizedBox(height: 12),
              TextField(controller: locationController, decoration: const InputDecoration(labelText: 'أضف موقع تسليم (Placeholder)'),),
              const SizedBox(height: 6),
              ElevatedButton(onPressed: () { if(locationController.text.isNotEmpty){ setState(() { deliveryLocations.add(locationController.text); locationController.clear(); }); } }, child: const Text('إضافة موقع تسليم')),
              const SizedBox(height: 12),
              Text('مواقع التسليم:'),
              for(var loc in deliveryLocations) Text('• $loc'),
              const SizedBox(height: 12),
              TextField(controller: priceController, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'سعر البضاعة'),),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: () { DatePicker.showDatePicker(context, showTitleActions: true, onConfirm: (date) { setState(() { shipmentDate = date; }); }, currentTime: DateTime.now()); }, child: Text('تاريخ الشحنة: ${shipmentDate??'اختر'}')),
              const SizedBox(height: 12),
              ElevatedButton(onPressed: () { DatePicker.showDatePicker(context, showTitleActions: true, onConfirm: (date) { setState(() { arrivalDate = date; }); }, currentTime: DateTime.now()); }, child: Text('تاريخ الوصول: ${arrivalDate??'اختر'}')),
              const SizedBox(height: 24),
              Center(child: ElevatedButton(onPressed: () { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('تم إضافة الشحنة (محليًا)'))); }, child: const Text('إرسال'))),
            ],
          ),
        ),
      ),
    );
  }
}
